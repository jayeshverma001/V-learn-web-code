import React from 'react';

function Pagenotfound() {
  return (
        <div>
            <p>Page Not Found</p>
        </div>
  );
}

export default Pagenotfound;
